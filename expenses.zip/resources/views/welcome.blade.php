@extends('layouts.app')

@section('content')
<div class="container">
    @include('alert')
    <div class="main">
        nothing like home
    </div>
</div>
@endsection
