<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-default">
                <div class="panel-heading">All Users</div>
                <div class="panel-body">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th>Role</th>
                                <?php if(Auth::user()->role == 1): ?>
                                    <th>Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($users as $user): ?>
                                <?php if($user->status == 0): ?>
                                    <tr class="danger">
                                <?php else: ?>
                                    <tr>
                                <?php endif; ?>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e(userStatus($user->status)); ?></td>
                                    <td><?php echo e(userRole($user->role)); ?></td>
                                    <?php if(Auth::user()->role == 1): ?>
                                        <td>
                                            <a href="#" class="edit-detail" data-toggle="modal" data-target="#edit" data-id="<?php echo e($user->id); ?>"><i class="glyphicon glyphicon-edit"></i></a>&nbsp;
                                            <a href="#" class="delete-user" data-toggle="modal" data-target="#delete"  data-id="<?php echo e($user->id); ?>"><i class="glyphicon glyphicon-trash"></i></a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>    
                </div>
            </div>
        </div>
    </div>
</div>

<div id="edit" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit Details</h4>
            </div>
            <form class="form-horizontal" id="edit-form" role="form" method="POST" action="update-user">
                <?php echo csrf_field(); ?>

                <div class="modal-body">
                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <label class="col-md-4 control-label">Name</label>

                        <div class="col-md-6">
                            <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">

                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label class="col-md-4 control-label">E-Mail Address</label>

                        <div class="col-md-6">
                            <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('role') ? ' has-error' : ''); ?>">
                        <label class="col-md-4 control-label">User Role</label>

                        <div class="col-md-6">
                            <?php $roles = userRole(); ?>
                            <select class="form-control" name="role">
                                <option value="">--Select--</option>
                                <?php foreach($roles as $key => $role): ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($role); ?></option>
                                <?php endforeach; ?>
                            </select>
                            
                            <?php if($errors->has('role')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('role')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                        <label class="col-md-4 control-label">Active</label>
                        <div class="col-sm-6 control-label">
                            <input type="checkbox" class="pull-left" name="status" value="<?php echo e(old('status')); ?>">
                        </div>

                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('status')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <input type="hidden" name="id" value="">
                <div class="modal-footer">
                    <button type="submit" id="update-user" class="btn btn-primary">Save</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="delete" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <form name="delete-user" method="POST" action="delete-user">
            <?php echo csrf_field(); ?>

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Delete User</h4>
                </div>
                <div class="modal-body">
                    <h2><small>Delete User</small></h2>
                    <input type="hidden" class="delete-id" name="delete_id" value="">
                </div>
                <div class="modal-footer">
                    <button type="submit" id="delete-user" class="btn btn-warning">Delete</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </form> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>