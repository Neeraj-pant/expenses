<!DOCTYPE html>
<html>
<head>
	<title>Laravel</title>
</head>
<body>

<?php echo $__env->yieldContent('content'); ?>

</body>
</html>