<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Expenses</title>

    <!-- Fonts -->

    <link rel="stylesheet" href="<?php echo e(url('css/pace-theme-minimal.css')); ?>">

    <script src="<?php echo e(url('js/pace.min.js')); ?>" type="text/javascript" charset="utf-8" async defer></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700">
    
    <?php /* <link href="<?php echo e(elixir('css/app.css')); ?>" rel="stylesheet"> */ ?>

    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

    <link rel="stylesheet" href="<?php echo e(url('css/tables.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/app.css')); ?>">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>

    <script src="https://npmcdn.com/masonry-layout@4.0/dist/masonry.pkgd.min.js"></script>

    <script>
        $(function() {
            $( ".datepicker" ).datepicker();
        });
    </script>
    <style>
        body {
            font-family: 'Lato';
        }

        .fa-btn {
            margin-right: 6px;
        }
    </style>
</head>
<body id="app-layout" class="background">
    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">

                <!-- Collapsed Hamburger -->
                <!-- <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button> -->

                <!-- Branding Image -->
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    Expenses
                </a>

            </div>

            <div id="app-navbar-collapse">
                <!-- Left Side Of Navbar -->
                <ul class="nav">
                    <li class="svg-wrapper"><svg width=70px class="item-1" xmlns="http://www.w3.org/2000/svg"><rect width=70px height=35px class="shape"/></rect></svg><div class="text"><a href="<?php echo e(url('/home')); ?>">Home</a></div>
                    </li>
                    <li class="svg-wrapper"><svg width=90px class="item-2" xmlns="http://www.w3.org/2000/svg"><rect width=70px height=35px class="shape"/></rect></svg><div class="text"><a href="<?php echo e(url('/product/home')); ?>">Products</a></div>
                    </li>
                    <li class="svg-wrapper"><svg width=90px class="item-3" xmlns="http://www.w3.org/2000/svg"><rect width=70px height=35px class="shape"/></rect></svg><div class="text"><a href="<?php echo e(url('/add-user')); ?>">Add User</a></div>
                    </li>
                    <li class="svg-wrapper"><svg width=120px class="item-4" xmlns="http://www.w3.org/2000/svg"><rect width=70px height=35px class="shape"/></rect></svg><div class="text"><a href="<?php echo e(url('/user-list')); ?>">Manage Users</a></div>
                    </li>
                    <li class="svg-wrapper"><svg width=115px class="item-5" xmlns="http://www.w3.org/2000/svg"><rect width=70px height=35px class="shape"/></rect></svg><div class="text"><a href="<?php echo e(url('/create-group')); ?>">Create Group</a></div>
                    </li>
                    <li class="svg-wrapper"><svg width=130px class="item-6" xmlns="http://www.w3.org/2000/svg"><rect width=70px height=35px class="shape"/></rect></svg><div class="text"><a href="<?php echo e(url('/manage-group')); ?>">Manage Groups</a></div>
                    </li>
                    <?php if(Auth::guest()): ?>
                        <li class="svg-wrapper"><svg width=70px class="item-7" xmlns="http://www.w3.org/2000/svg"><rect width=70px height=35px class="shape"/></rect></svg><div class="text"><a href="<?php echo e(url('/login')); ?>">Login</a></div>
                        </li>
                    <?php else: ?>
                        <li class="username1 drop">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            <ul>
                                <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <li><div class="inputbox"><input type="text" id="search" required="required"/> <button type="reset" class="del"></button></div></li>
                </ul>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    <script src="http://code.highcharts.com/highcharts.js"></script>
    <script src="<?php echo e(url('js/ajax.js')); ?>" type="text/javascript" charset="utf-8" async defer></script>
    <script src="<?php echo e(url('js/element.js')); ?>" type="text/javascript" charset="utf-8" async defer></script>
    <script src="<?php echo e(url('js/modal.js')); ?>" type="text/javascript" charset="utf-8" async defer></script>
    <script src="<?php echo e(url('js/panel.js')); ?>" type="text/javascript" charset="utf-8" async defer></script>
    <script src="<?php echo e(url('js/custom.js')); ?>" type="text/javascript" charset="utf-8" async defer></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <script>

</script>
</body>
</html>
