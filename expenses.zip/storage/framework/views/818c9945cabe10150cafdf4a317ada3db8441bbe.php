<?php $__env->startSection('content'); ?>
<div class="container back full">
    <div class="panel-heading"><h1>Add User</h1></div>
    <?php echo $__env->make('alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <form method="POST" action="<?php echo e(url('/save-user')); ?>">
        <?php echo csrf_field(); ?>

        <input placeholder="Name" type="text" name="name" value="<?php echo e(old('name')); ?>" required="">
        <?php if($errors->has('name')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('name')); ?></strong>
            </span>
        <?php endif; ?>
        <input type="email" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required="">
        <?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>
        <input type="password" placeholder="Password" name="password" required="">
        <?php if($errors->has('password')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
        <?php endif; ?>
        <?php $roles = userRole(); ?>
    	<select name="role" required="">
            <option value="">--Select--</option>
            <?php foreach($roles as $key => $role): ?>
                <option value="<?php echo e($key); ?>"><?php echo e($role); ?></option>
            <?php endforeach; ?>
        </select>                
        <?php if($errors->has('role')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('role')); ?></strong>
            </span>
        <?php endif; ?>
        <input type="hidden" name="status" value="1">
        <button type="submit" class="btn btn-primary">
            <i class="fa fa-btn fa-plus"></i>Add User
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>