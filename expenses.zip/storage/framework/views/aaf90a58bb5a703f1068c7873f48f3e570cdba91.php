<?php $__env->startSection('content'); ?>
	<table class="table table-stripped table-hover">
		<thead>
			<tr>
				<td>Name</td>
				<td>Email</td>
				<td>Status</td>
				<td>Action</td>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>-</td>
			</tr>
		</tbody>
	</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>