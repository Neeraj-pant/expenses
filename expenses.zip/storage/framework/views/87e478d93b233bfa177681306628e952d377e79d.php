<?php $__env->startSection('content'); ?>
    <div class="container ">
        <h1>Entries</h1>
        <?php echo $__env->make('alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="grid">
            <?php foreach( $users as $user ): ?>
                <div class="grid-item">
                    <?php $pObj = new App\Product; $products = $pObj->getProduct($user->id, $user->group_id); ?>
                    <div class="list-group">
                        <h2><?php echo e($user->name); ?><span class="total">₹ <?php echo e($products->total); ?></span></h2>
                        <div class="entry-wrapper">
                            <?php if( $products->total == 0): ?>
                                <p style="color:#fff;">No Data Found !</p>
                            <?php endif; ?>
                            <?php foreach($products as $product): ?>
                                <div class="cont_princ_lists">
                                    <ul>
                                        <li class="list_shopping li_num_0_1">
                                            <div class="col_md_1_list">
                                                <p><?php echo e($product->name); ?></p>
                                            </div>
                                            <div class="col_md_2_list">
                                                <p><?php echo e(date('d-M-Y', strtotime($product->date))); ?></p>
                                            </div>
                                            <div class="col_md_3_list">
                                                <div class="cont_text_date">
                                                    <p>₹ &nbsp;<?php echo e($product->price); ?> </p>
                                                </div>
                                                <?php if($user->id == Auth::user()->id): ?>
                                                    <div class="cont_btns_options">
                                                        <ul>
                                                            <li>
                                                                <a href="<?php echo e(url('product/delete/'.$product->id)); ?>" class="delete-product" onclick="finish_action('0','0_1');"><i class="fa fa-trash"></i></a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script>
        $('.grid').masonry({
            itemSelector: '.grid-item'
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>