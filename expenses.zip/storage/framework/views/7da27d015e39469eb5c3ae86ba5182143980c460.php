<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Users</h1>
    <?php echo $__env->make('alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="table-responsive-vertical shadow-z-1">
        <table id="table" class="table table-mc-light-blue">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Stats</th>
                    <th>Role</th>
                    <?php if(Auth::user()->role == 1): ?>
                        <th>Actions</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach($users as $user): ?>
                    <?php if($user->status == 0): ?>
                        <tr class="danger">
                    <?php else: ?>
                        <tr>
                    <?php endif; ?>
                        <td data-title="Name"><?php echo e($user->name); ?></td>
                        <td data-title="Email"><?php echo e($user->email); ?></td>
                        <td data-title="Status"><?php echo e(userStatus($user->status)); ?></td>
                        <td data-title="Role"><?php echo e(userRole($user->role)); ?></td>
                        <?php if(Auth::user()->role == 1): ?>
                            <td data-title="Actions">
                                <a href="#" class="edit-detail follow-single modal-open" data-id="<?php echo e($user->id); ?>"><i class="fa fa-pencil"></i></a>&nbsp;
                                <a href="#" class="delete-user follow-single modal-open-2" data-id="<?php echo e($user->id); ?>"><i class="fa fa-trash"></i></a>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>






<div id="modal-container">
    <div id="edit" class="modal-background">
        <div class="modal">
            <a href="#" class="close close-modal">&times;</button></a>
            <form class="form-horizontal" id="edit-form" role="form" method="POST" action="update-user">
                <?php echo csrf_field(); ?>

                <input type="text" placeholder="Name" name="name" value="<?php echo e(old('name')); ?>" required="">
                <input type="email" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required="">
                <?php $roles = userRole(); ?>
                <select name="role" required="">
                    <option value="">--Select--</option>
                    <?php foreach($roles as $key => $role): ?>
                        <option value="<?php echo e($key); ?>"><?php echo e($role); ?></option>
                    <?php endforeach; ?>
                </select>
                <label class="rember-label" for="#active">
                    <input type="checkbox" id="active" name="status" value="<?php echo e(old('status')); ?>">Active
                </label>
                <input type="hidden" name="id" value="">
                <div class="modal-footer">
                    <button type="submit" id="update-user" class="btn btn-primary">Save</button>
                    <button type="button" class="close-modal" data-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>



<div id="modal-container-2">
    <div id="delete" class="modal-background">
        <div class="modal">
            <a href="#" class="close close-modal">&times;</button></a>
            <h2>Delete User</h2>
            <form name="delete-user" method="POST" action="delete-user">
                <?php echo csrf_field(); ?>

                <input type="hidden" class="delete-id" name="delete_id" value="">                
                <div class="modal-footer">
                    <button type="submit" id="delete-user" class="btn btn-warning">Delete</button>
                    <button type="button" class="close-modal" data-dismiss="modal">Cancel</button>
                </div>
            </form> 
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>