<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="row">
		<div class="col-sm-6 col-sm-offset-3">
			<form method="post" action="<?php echo e(url('/login/login')); ?>">
				<?php if(count($errors) > 0): ?>
				    <div class="alert alert-danger">
				        <ul>
				            <?php foreach($errors->all() as $error): ?>
				                <li><?php echo e($error); ?></li>
				            <?php endforeach; ?>
				        </ul>
				    </div>
				<?php endif; ?>
				<?php echo csrf_field(); ?>

			    <div class="form-group">
				    <label for="exampleInputEmail1">Email address</label>
				    <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Email" value="<?php echo e(old('email')); ?>">
			    </div>
			    <div class="form-group">
				    <label for="exampleInputPassword1">Password</label>
				    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
			    </div>
			    <div class="checkbox">
				    <label>
				    	<input type="checkbox" name="remember"> Remember me
			    	</label>
			    </div>
		 		<button type="submit" class="btn btn-default">Login</button>
			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('login.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>