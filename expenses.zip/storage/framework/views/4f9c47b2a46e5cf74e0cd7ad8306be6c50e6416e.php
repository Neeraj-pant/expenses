<?php $__env->startSection('content'); ?>
<div class="container main">
    <h1 class="no-wrap">Group List</h1>
    <?php echo $__env->make('alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="group-layout">
        <div class="layout-type">
            <a href="#" data-type="panels"><i class="fa fa-align-justify"></i></a><a href="#" class="active" data-type="tables"><i class="fa fa-th"></i></a>
        </div>
    </div>
    <div class="panels">
        <div class="panel-wrapper">
            <div class="panel">
                <?php $numbers = range(1, 9); shuffle($numbers); $i=0; ?>
                <?php foreach($groups as $group): ?>
                    <div class="panel-element">
                        <?php if(Auth::check()): ?>
                            <div class="element-actions">
                                <?php if($group['active_user_delete'] == 0 || $group['active_user_delete'] === false): ?>
                                    <?php if($group['other_user_delete'] >= 1): ?>
                                        <span class="text-info"><?php echo e($group['other_user_delete']); ?> Delete Request for this group</span>
                                    <?php endif; ?>
                                    <a href="#" class="delete-group modal-open panel-button btn-action btn-hide" data-id="<?php echo e($group['id']); ?>"><i class="fa fa-trash"></i></a>
                                <?php else: ?>
                                    <a href="#" class="panel-button btn-action btn-heart delete-group" ><i class="fa fa-check"></i></a>
                                    <span class="text-info">Delete Request Sent</span>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <div class="element-content">
                            <button class="panel-button btn btn-more">
                                <i class="fa fa-ellipsis-h icon-closed"></i>
                                <i class="fa fa-times icon-open"></i>
                                <i class="fa fa-heart-o icon-hearted"></i>
                            </button>
                            <div class="content-post">
                                <div class="post-avatar"><img src="<?php echo e(url(BACKGROUND_PATH.$numbers[$i].'.jpg')); ?>" ><?php $i++; ?></div>
                                <div class="post-content">
                                    <span class="post-title"><?php echo e($group['name']); ?></span>
                                    <p class="post-body"><?php echo e($group['members']); ?></p>
                                     <?php if($group['active_user_delete'] == 0 || $group['active_user_delete'] === false): ?>
                                        <?php if($group['other_user_delete'] >= 1): ?>
                                            <span class="text-info"><?php echo e($group['other_user_delete']); ?> Delete Request for this group</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-info">Delete Request Sent</span>
                                        <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div class="tables">
        <div class=" table-responsive-vertical shadow-z-1">
            <table id="table" class="table table-mc-light-blue">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Members</th>
                        <?php if(Auth::user()->role == 1): ?>
                            <th>Action</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($groups as $group): ?>
                        <tr>
                            <td data-title="Name"><?php echo e($group['name']); ?></td>
                            <td data-title="members"><?php echo e($group['members']); ?></td>
                            <?php if(Auth::check()): ?>
                                <td data-title="sctions">
                                    <!-- <a href="#" class="edit-group"><i class="glyphicon glyphicon-edit"></i></a>&nbsp; -->
                                    <a href="group-detail/<?php echo e($group['id']); ?>" class="report btn btn btn-orange btn-border-rev"><i class="fa fa-paper"></i>Get Detail</a>
                                    <?php if($group['active_user_delete'] == 0 || $group['active_user_delete'] === false): ?>
                                        <a href="#" class="delete-group modal-open" data-id="<?php echo e($group['id']); ?>"><i class="fa fa-trash"></i></a>
                                        <?php if($group['other_user_delete'] >= 1): ?>
                                            <span class="text-info"><?php echo e($group['other_user_delete']); ?> Delete Request for this group</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <a href="#" class="delete-group" ><i class="fa fa-check"></i></a>
                                        <span class="text-info">Delete Request Sent</span>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

<!-- <div class="content">
  <h1>Modal Animations</h1>
  <div class="buttons">
    <div id="one" class="button">Unfolding</div>
    <div id="two" class="button">Revealing</div>
    <div id="three" class="button">Uncovering</div>
    <div id="four" class="button">Blow Up</div><br>
    <div id="five" class="button">Meep Meep</div>
    <div id="six" class="button">Sketch</div>
    <div id="seven" class="button">Bond</div>
  </div>
</div> -->

<div id="modal-container">
    <div id="delete" class="modal-background">
        <div class="modal">
            <a href="#" class="close close-modal">&times;</button></a>
            <form name="delete-group" method="POST" action="delete-group">
                <?php echo csrf_field(); ?>

                <div class="modal-body">
                    <h2><small class="text-primary">Delete User</small></h2>
                    <h3><small class="text-info">After your approval delete request will be send to other group member.</small></h3>
                    <h3><small class="text-info">Group will be deleted after other members approval.</small></h3>
                    <input type="hidden" class="delete-group-id" name="delete_group_id" value="">
                </div>
                <div class="modal-footer">
                    <button type="submit" id="delete-user" class="btn btn-navy btn-fill-vert-o">Proceed to Delete</button>
                    <button type="button" class="close-modal btn btn-purple btn-fill-vert" data-dismiss="modal">Cancel</button>
                </div>
            </form> 
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>