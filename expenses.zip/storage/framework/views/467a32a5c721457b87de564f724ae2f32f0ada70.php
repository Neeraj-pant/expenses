<?php $__env->startSection('content'); ?>
<div class="container ">
    <h1>Entries</h1>
    <?php echo $__env->make('alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php if(App::make('app\Http\Controllers\productController')->isUserInGroup(Request::segment(3))): ?>
        <button class="follow-ic modal-open product-entry" data-id=<?php echo e(Request::segment(3)); ?>>Make Entry</button>
    <?php endif; ?>
    <div class="grid">
        <?php foreach( $users as $user ): ?>
            <div class="grid-item">
                <?php $pObj = new App\Product; $products = $pObj->getProduct($user->id, $user->group_id); ?>
                <div class="list-group">
                    <h2><?php echo e($user->name); ?><span class="total"><?php echo e(CURRENCY); ?> <?php echo e($products->total); ?></span></h2>
                    <div class="entry-wrapper">
                        <?php if( $products->total == 0): ?>
                            <p>No Data Found !</p>
                        <?php endif; ?>
                        <?php foreach($products as $product): ?>
                            <div class="cont_princ_lists">
                                <ul>
                                    <li class="list_shopping li_num_0_1">
                                        <div class="col_md_1_list">
                                            <p><?php echo e($product->name); ?></p>
                                        </div>
                                        <div class="col_md_2_list">
                                            <p><?php echo e(date('d-M-Y', strtotime($product->date))); ?></p>
                                        </div>
                                        <div class="col_md_3_list">
                                            <div class="cont_text_date">
                                                <p><?php echo e(CURRENCY); ?> &nbsp;<?php echo e($product->price); ?> </p>      
                                            </div>
                                            <?php if($user->id == Auth::user()->id): ?>
                                                <div class="cont_btns_options">
                                                    <ul>
                                                        <li>
                                                            <a href="<?php echo e(url('product/delete/'.$product->id)); ?>" class="delete-product" onclick="finish_action('0','0_1');"><i class="fa fa-trash"></i></a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>



<div id="modal-container">
	<div id="entry" class="modal-background" >
	    <div class="modal">
	        <a href="#" class="close close-modal">&times;</button></a>
	        <form id="save-product-form" name="product-entry" method="POST" action="<?php echo e(url('product/save')); ?>">
	            <?php echo csrf_field(); ?>

	            <h2 class="modal-title text-info">Add Product</h2>
	            <p class="text-success bg-info success"></p>
	            <div class="modal-body">
	                <input type="text" placeholder="Name" name="name" value="<?php echo e(old('name')); ?>" required="">
	                <div class="input-group-mix">
	                    <span class="input-group-addon"><?php echo e(CURRENCY); ?></span>
	                    <input type="number" placeholder="Price" min="0" name="price" value="<?php echo e(old('price')); ?>" required="">
	                </div>
	                <div class="data-group">
	                    <input type='text' name="date" placeholder="Date" class="datepicker" id='datepicker' value="<?php echo e(date('d/m/Y')); ?>" min="0" required="" />
	                    <span class="input-group-addon">
	                        <span class="glyphicon glyphicon-calendar"></span>
	                    </span>
	                </div>
	                <p class="text-danger bg-danger errors"></p>
	                <input type="hidden" class="product-group-id" name="product_group_id" value="">
	                <input type="hidden" name="product_url" value="<?php echo e(Request::segment(3)); ?>">
	                <div class="modal-footer">
	                    <!-- <button type="button" id="add-product-ajax" class="btn btn-primary">Save &amp; Continue</button> -->
	                    <button type="submit" id="add-product" class="btn btn-info">Save</button>
	                    <button type="button" class="close-modal btn btn-purple btn-fill-vert" data-dismiss="modal">Cancel</button>
	                 </div>
	            </div>
	        </form> 
	    </div>
	</div>
</div>


<script>
    $('.grid').masonry({
      itemSelector: '.grid-item'
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>