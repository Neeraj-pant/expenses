<?php $__env->startSection('content'); ?>
<div class="container back full">
    <?php echo $__env->make('alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="panel-heading"><h1>Login</h1></div>
    <form method="POST" action="<?php echo e(url('/login')); ?>">
        <?php echo csrf_field(); ?>

        <input type="email" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required="">
        <?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>
        <input type="password" placeholder="Password" name="password" required="">
        <?php if($errors->has('password')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
        <?php endif; ?>
        <label class="rember-label" for="#remember">
            <input type="checkbox" id="remember" name="remember"> Remember Me
        </label>
        <button type="submit" class="btn btn-primary">
            <i class="fa fa-btn fa-sign-in"></i>Login
        </button>
        <a class="btn btn-link forgot" href="<?php echo e(url('/password/reset')); ?>">Forgot Your Password?</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>