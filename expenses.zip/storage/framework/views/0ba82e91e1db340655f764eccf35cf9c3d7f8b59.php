<div class="date_filter">
	<div class="filter-wrapper">
		<label>Start Date</label>
		<input type="text" name="start_date" class="start-date datepicker" value="">
	</div>
	<div class="filter-wrapper">
		<label>End Date</label>
		<input type="text" name="end_date" class="end-date datepicker" value="<?php echo e(date('m/d/Y')); ?>">
	</div>
</div>